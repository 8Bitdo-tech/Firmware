------------------------------------------------------------------------------------------------------
Update
------------------------------------------------------------------------------------------------------


Date: 2018/3/6 V1.13
--------------------
1. Added the support for Xbox One S Bluetooth controller.
*Vibration is supported on Switch and X-input mode.

2. Vibration on PS4 controller can be modified to two levels �C strong/weak.
*Key command for switching between two levels: L+R+SELECT
  
Date: 2018/2/10 V1.12
---------------------
1. Fixed PS4 controller lost connection issue. 
2. Added function that hold down PS4 controller's HOME button 3 seconds can power off the controller.

Date: 2018/1/31 V1.11
---------------------
1. Fixed the WiiU Pro controller's right joystick mapping issue.
2. Enhanced the Bluetooth auto-reconnection and reduced its auto-reconnect timing.
3. Adjusted the hot keys for switching the USB mode.
	XINPUT: SELECT+DPAD_UP
	MacOS:  SELECT+DPAD_RIGHT
	DINPUT: SELECT+DPAD_LEFT

Date: 2018/1/29 V1.10
---------------------
1. Fixed the Wii mote connected but buttons no respond issue.
2. Add PS3 controller HOME button back to Switch menu.

Online Manual: http://download.8bitdo.com/Manual/Receiver/usb_adapter/8Bitdo_USB_RR_Manual.pdf

